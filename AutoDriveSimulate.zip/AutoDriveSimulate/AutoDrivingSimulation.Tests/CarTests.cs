﻿using Xunit;
using AutoDrivingSimulation;

namespace AutoDrivingSimulation.Tests
{
    public class CarTests
    {
        [Fact]
        public void Car_Move_North_IncreasesY()
        {
            // Arrange
            var car = new Car("TestCar", 0, 0, 'N', "M");

            // Act
            car.Move();

            // Assert
            Assert.Equal(1, car.Y);
        }

        [Fact]
        public void Car_Move_South_DecreasesY()
        {
            var car = new Car("TestCar", 0, 1, 'S', "M");

            car.Move();

            Assert.Equal(0, car.Y);
        }

        [Fact]
        public void Car_TurnLeft_FromNorth_ToWest()
        {
            var car = new Car("TestCar", 0, 0, 'N', "");

            car.TurnLeft();

            Assert.Equal('W', car.Direction);
        }

        [Fact]
        public void Car_TurnRight_FromNorth_ToEast()
        {
            var car = new Car("TestCar", 0, 0, 'N', "");

            car.TurnRight();

            Assert.Equal('E', car.Direction);
        }

        [Fact]
        public void CarSimulation_Detects_Collision()
        {
            var carA = new Car("A", 0, 0, 'N', "M");
            var carB = new Car("B", 0, 1, 'S', "M");

            string result = CarSimulation.Simulate(carA, carB);

            Assert.Contains("collides", result);
        }
    }
}
