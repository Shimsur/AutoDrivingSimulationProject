﻿using System;

namespace AutoDrivingSimulation
{
    // Car Class Definition
    public class Car
    {
        public string Name { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public char Direction { get; set; }
        public string Commands { get; set; }

        public Car(string name, int x, int y, char direction, string commands)
        {
            Name = name;
            X = x;
            Y = y;
            Direction = direction;
            Commands = commands.ToUpper(); // Ensure commands are uppercase
        }

        // Move the car based on the direction
        public void Move()
        {
            switch (Direction)
            {
                case 'N': Y += 1; break; // North moves up
                case 'S': Y -= 1; break; // South moves down
                case 'E': X += 1; break; // East moves right
                case 'W': X -= 1; break; // West moves left
            }
        }

        // Turn the car left
        public void TurnLeft()
        {
            switch (Direction)
            {
                case 'N': Direction = 'W'; break;
                case 'S': Direction = 'E'; break;
                case 'E': Direction = 'N'; break;
                case 'W': Direction = 'S'; break;
            }
        }

        // Turn the car right
        public void TurnRight()
        {
            switch (Direction)
            {
                case 'N': Direction = 'E'; break;
                case 'S': Direction = 'W'; break;
                case 'E': Direction = 'S'; break;
                case 'W': Direction = 'N'; break;
            }
        }

        // Execute a sequence of commands
        public void ExecuteCommands()
        {
            foreach (char command in Commands)
            {
                if (command == 'M') Move();
                else if (command == 'L') TurnLeft();
                else if (command == 'R') TurnRight();
            }
        }
    }

    // Simulation Class
    public static class CarSimulation
    {
        public static string Simulate(Car carA, Car carB)
        {
            // Execute movements for both cars
            carA.ExecuteCommands();
            carB.ExecuteCommands();

            // Collision detection
            if (carA.X == carB.X && carA.Y == carB.Y)
            {
                return $"{carB.Name} collides with {carA.Name} at ({carA.X}, {carA.Y})";
            }

            return "Simulation complete!";
        }
    }

    // Main Program Class
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("### Auto Driving Simulation ###");

            // Get user input for Car A
            var carA = GetCarDetails("A");
            var carB = GetCarDetails("B");

            Console.WriteLine($"Car A starts at ({carA.X}, {carA.Y}) facing {carA.Direction}");
            Console.WriteLine($"Car B starts at ({carB.X}, {carB.Y}) facing {carB.Direction}");

            // Move cars and check positions
            carA.ExecuteCommands();
            carB.ExecuteCommands();

            Console.WriteLine($"Car A final position: ({carA.X}, {carA.Y}), Facing {carA.Direction}");
            Console.WriteLine($"Car B final position: ({carB.X}, {carB.Y}), Facing {carB.Direction}");

            // Simulate interaction between cars
            var result = CarSimulation.Simulate(carA, carB);
            Console.WriteLine(result);

            Console.WriteLine("Simulation Ended!");
        }

        // Method to get car details from user
        static Car GetCarDetails(string carName)
        {
            Console.WriteLine($"Enter details for Car {carName}:");

            Console.Write("Enter starting X coordinate: ");
            int x = GetValidInteger();

            Console.Write("Enter starting Y coordinate: ");
            int y = GetValidInteger();

            Console.Write("Enter starting direction (N, S, E, W): ");
            char direction = GetValidDirection();

            Console.Write("Enter movement commands (M, L, R): ");
            string commands = Console.ReadLine().ToUpper();

            return new Car(carName, x, y, direction, commands);
        }

        // Validate integer input
        static int GetValidInteger()
        {
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out int value))
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter an integer: ");
            }
        }

        // Validate direction input
        static char GetValidDirection()
        {
            while (true)
            {
                char dir = char.ToUpper(Console.ReadKey().KeyChar);
                Console.WriteLine(); // Move to the next line

                if (dir == 'N' || dir == 'S' || dir == 'E' || dir == 'W')
                {
                    return dir;
                }
                Console.Write("Invalid direction. Enter N, S, E, or W: ");
            }
        }
    }
}
